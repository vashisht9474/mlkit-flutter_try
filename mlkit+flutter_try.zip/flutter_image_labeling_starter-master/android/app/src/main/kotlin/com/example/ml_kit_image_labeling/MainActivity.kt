package com.example.ml_kit_image_labeling


import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity() {
}
